# 保留数据模型（Gson 反射 / 手写解析混合场景）
-keep class com.fengyin.music.data.model.** { *; }

# OkHttp / Retrofit
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn retrofit2.**
-keepattributes Signature
-keepattributes *Annotation*

# Media3
-dontwarn androidx.media3.**
