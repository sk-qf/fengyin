package com.fengyin.music

import android.app.Application
import com.fengyin.music.player.MusicPlayer

/**
 * 全局入口：提前初始化播放器实例，保证 Activity / Service 共用同一个 ExoPlayer。
 */
class FengYinApp : Application() {

    override fun onCreate() {
        super.onCreate()
        MusicPlayer.init(this)
    }
}
