package com.fengyin.music.data.model

/**
 * 一行歌词。
 *
 * 源码中歌词时间是「秒」（浮点），Android 侧统一转成毫秒便于 seek 与比较。
 */
data class LyricLine(
    val timeMs: Long,
    val text: String
)
