package com.fengyin.music.data.model

/**
 * 音质档位。
 *
 * 对应源码 QUALITY_MAP：
 *   { '128k': 'standard', '320k': 'exhigh', 'flac': 'lossless' }
 */
enum class Quality(val label: String, val apiLevel: String) {
    STANDARD("标准 128K", "standard"),
    HIGH("高品质 320K", "exhigh"),
    LOSSLESS("无损 FLAC", "lossless");

    val fileExtension: String get() = if (this == LOSSLESS) "flac" else "mp3"
}
