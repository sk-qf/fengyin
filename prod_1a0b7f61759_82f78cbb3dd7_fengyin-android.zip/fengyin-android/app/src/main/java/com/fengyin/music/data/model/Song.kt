package com.fengyin.music.data.model

/**
 * 歌曲实体。
 *
 * 对应源码 searchMusic() 中：
 *   res.abslist.map(_ => ({ id: _.MUSICRID.replace("MUSIC_", ""), ... }))
 * 即 playlist 中的每一项。
 *
 * [id] 必须是纯数字 musicId —— 播放解析接口、歌词接口、高清封面接口都依赖它。
 */
data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val artwork: String? = null
)

/**
 * 一页搜索结果。
 * [isEnd] 对应源码 `(+res.PN + 1) * +res.RN >= +res.TOTAL`。
 */
data class SearchPage(
    val songs: List<Song>,
    val isEnd: Boolean
)
