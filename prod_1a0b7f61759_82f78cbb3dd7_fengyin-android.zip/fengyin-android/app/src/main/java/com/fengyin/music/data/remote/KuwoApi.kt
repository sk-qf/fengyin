package com.fengyin.music.data.remote

import okhttp3.ResponseBody
import retrofit2.http.GET
import retrofit2.http.Url

/**
 * 酷我接口访问层。
 *
 * 搜索接口在 search.kuwo.cn，歌词/封面接口在 m.kuwo.cn，域名不同，
 * 因此统一用 @Url 传绝对地址，避免维护多个 Retrofit 实例。
 */
interface KuwoApi {

    @GET
    suspend fun get(@Url url: String): ResponseBody
}
