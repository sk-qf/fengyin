package com.fengyin.music.data.remote

import androidx.core.text.HtmlCompat
import com.fengyin.music.data.model.LyricLine
import com.fengyin.music.data.model.SearchPage
import com.fengyin.music.data.model.Song
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.stream.JsonReader
import java.io.StringReader

/**
 * 酷我响应解析器。
 *
 * 说明：search.kuwo.cn/r.s 返回的并非严格 JSON（key/value 可能用单引号、甚至被 jsonp 包裹），
 * 因此统一用 lenient 模式的 JsonReader 解析，对应源码里的 `try JSON.parse catch eval`。
 */
object KuwoParser {

    private fun JsonObject.str(key: String): String? {
        val element = get(key) ?: return null
        if (element.isJsonNull || !element.isJsonPrimitive) return null
        return runCatching { element.asString }.getOrNull()
    }

    private fun JsonObject.int(key: String): Int? = str(key)?.toIntOrNull()

    /** 源码 decodeHTML() 等价实现 */
    private fun decodeHtml(raw: String?): String {
        if (raw.isNullOrEmpty()) return ""
        return runCatching {
            HtmlCompat.fromHtml(raw, HtmlCompat.FROM_HTML_MODE_LEGACY).toString()
        }.getOrDefault(raw)
    }

    /** 源码 artworkShort2Long() */
    private fun artworkShort2Long(short: String?): String? {
        if (short.isNullOrEmpty()) return null
        val idx = short.indexOf('/')
        return if (idx != -1) "https://img4.kuwo.cn/star/albumcover/1080${short.substring(idx)}" else null
    }

    /** 去掉 callback(...) / jsonp(...) 包裹 */
    private fun stripJsonp(raw: String): String {
        var text = raw.trim()
        if (text.startsWith("callback(") || text.startsWith("jsonp(")) {
            val start = text.indexOf('(')
            val end = text.lastIndexOf(')')
            if (start != -1 && end > start) text = text.substring(start + 1, end)
        }
        return text
    }

    private fun parseLenient(raw: String): JsonObject {
        val reader = JsonReader(StringReader(stripJsonp(raw))).apply { isLenient = true }
        return JsonParser.parseReader(reader).asJsonObject
    }

    /**
     * 解析搜索结果：abslist -> List<Song>，并计算是否到达末页。
     */
    fun parseSearch(raw: String): SearchPage {
        val root = runCatching { parseLenient(raw) }.getOrNull()
            ?: return SearchPage(emptyList(), true)

        val array = root.getAsJsonArray("abslist") ?: return SearchPage(emptyList(), true)

        val songs = array.mapNotNull { element ->
            val obj = runCatching { element.asJsonObject }.getOrNull() ?: return@mapNotNull null
            val musicRid = obj.str("MUSICRID") ?: return@mapNotNull null
            val title = decodeHtml(obj.str("NAME"))
            if (title.isBlank()) return@mapNotNull null
            Song(
                id = musicRid.replace("MUSIC_", ""),
                title = title,
                artist = decodeHtml(obj.str("ARTIST")),
                album = decodeHtml(obj.str("ALBUM")),
                artwork = artworkShort2Long(obj.str("web_albumpic_short"))
            )
        }

        val pn = root.int("PN") ?: 0
        val rn = root.int("RN") ?: songs.size
        val total = root.int("TOTAL") ?: 0
        val isEnd = total > 0 && (pn + 1) * rn >= total

        return SearchPage(songs, isEnd)
    }

    /**
     * 解析歌词：data.lrclist[].time / lineLyric
     * time 可能是 "01:23.45" 也可能是浮点秒，两种都兼容（对应源码 fetchLyrics）。
     */
    fun parseLyrics(raw: String): List<LyricLine> {
        val root = runCatching { parseLenient(raw) }.getOrNull() ?: return emptyList()
        val data = root.getAsJsonObject("data") ?: return emptyList()
        val list = data.getAsJsonArray("lrclist") ?: return emptyList()

        return list.mapNotNull { element ->
            val obj = runCatching { element.asJsonObject }.getOrNull() ?: return@mapNotNull null
            val timeRaw = obj.str("time") ?: return@mapNotNull null
            val text = decodeHtml(obj.str("lineLyric"))
            if (text.isBlank()) return@mapNotNull null
            LyricLine(parseTimeToMs(timeRaw), text)
        }.sortedBy { it.timeMs }
    }

    /**
     * 解析高清封面：data.songinfo.pic，并把像素尺寸替换为 800（对应源码 fetchHighResArtwork）。
     */
    fun parseArtwork(raw: String): String? {
        val root = runCatching { parseLenient(raw) }.getOrNull() ?: return null
        val data = root.getAsJsonObject("data") ?: return null
        val songInfo = data.getAsJsonObject("songinfo") ?: return null
        val pic = songInfo.str("pic") ?: return null
        if (pic.isBlank()) return null

        var url = pic.replaceFirst(Regex("^http:", RegexOption.IGNORE_CASE), "https:")
        if (url.contains("starheads/")) {
            url = url.replace(Regex("starheads/\\d+"), "starheads/800")
        } else if (url.contains("albumcover/")) {
            url = url.replace(Regex("albumcover/\\d+"), "albumcover/800")
        }
        return url
    }

    private fun parseTimeToMs(raw: String): Long {
        val value = raw.trim()
        return if (value.contains(':')) {
            val parts = value.split(':')
            if (parts.size == 2) {
                val minutes = parts[0].toLongOrNull() ?: 0L
                val seconds = parts[1].toDoubleOrNull() ?: 0.0
                minutes * 60_000L + (seconds * 1000).toLong()
            } else 0L
        } else {
            ((value.toDoubleOrNull() ?: 0.0) * 1000).toLong()
        }
    }
}
