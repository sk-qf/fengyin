package com.fengyin.music.data.remote

import com.fengyin.music.data.repository.MusicRepository
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import java.util.concurrent.TimeUnit

/**
 * 极简依赖装配。项目规模不大，不引入 DI 框架。
 */
object NetworkModule {

    private const val UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

    val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .followRedirects(true)
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .header("User-Agent", UA)
                    .header("Referer", "http://m.kuwo.cn/")
                    .build()
                chain.proceed(request)
            }
            .build()
    }

    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl("https://m.kuwo.cn/")
            .client(okHttpClient)
            .build()
    }

    private val api: KuwoApi by lazy { retrofit.create(KuwoApi::class.java) }

    val repository: MusicRepository by lazy { MusicRepository(api) }
}
