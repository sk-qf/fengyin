package com.fengyin.music.data.repository

import com.fengyin.music.data.model.LyricLine
import com.fengyin.music.data.model.Quality
import com.fengyin.music.data.model.SearchPage
import com.fengyin.music.data.remote.KuwoApi
import com.fengyin.music.data.remote.KuwoParser
import java.net.URLEncoder

/**
 * 音乐数据仓库 —— 承载网页版源码的整条数据流：
 *
 *   关键词 -> search() -> 酷我搜索接口 -> abslist -> List<Song>
 *   点击歌曲 -> playUrl() -> 第三方解析接口 -> 音频直链
 *             -> lyrics() -> 歌词接口 -> List<LyricLine>
 *             -> highResArtwork() -> 高清封面
 *
 * 注意：网页版依赖 CORS 代理，Android 原生请求无跨域限制，故直接访问源站。
 */
class MusicRepository(private val api: KuwoApi) {

    suspend fun search(keyword: String, page: Int): SearchPage {
        val url = buildString {
            append("http://search.kuwo.cn/r.s?")
            append("client=kt&all=").append(URLEncoder.encode(keyword, "UTF-8"))
            append("&pn=").append((page - 1).coerceAtLeast(0))
            append("&rn=").append(PAGE_SIZE)
            append("&uid=2574109560&ver=kwplayer_ar_8.5.4.2&vipver=1")
            append("&ft=music&cluster=0&strategy=2012&encoding=utf8&rformat=json&vermerge=1&mobi=1")
        }
        val raw = api.get(url).string()
        return KuwoParser.parseSearch(raw)
    }

    suspend fun lyrics(songId: String): List<LyricLine> {
        val raw = api.get(songInfoUrl(songId)).string()
        return KuwoParser.parseLyrics(raw)
    }

    suspend fun highResArtwork(songId: String): String? {
        val raw = api.get(songInfoUrl(songId)).string()
        return KuwoParser.parseArtwork(raw)
    }

    /** 音频直链（第三方解析接口，对应源码 playSong / downloadCurrentSong） */
    fun playUrl(songId: String, quality: Quality): String =
        "https://music.nxinxz.com/kw.php?id=$songId&level=${quality.apiLevel}&type=mp3"

    private fun songInfoUrl(songId: String) =
        "http://m.kuwo.cn/newh5/singles/songinfoandlrc?musicId=$songId&httpStatus=1"

    companion object {
        const val PAGE_SIZE = 30
    }
}
