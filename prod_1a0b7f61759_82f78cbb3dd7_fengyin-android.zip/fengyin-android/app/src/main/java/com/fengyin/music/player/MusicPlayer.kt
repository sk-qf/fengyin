package com.fengyin.music.player

import android.content.Context
import androidx.core.net.toUri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.fengyin.music.data.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * 播放器对外状态。
 * positionMs / durationMs 对应网页版 audio 元素的 currentTime / duration。
 */
data class PlayerState(
    val song: Song? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L
)

/**
 * 播放内核：单例持有 ExoPlayer，UI 与 PlaybackService（媒体通知）共用同一实例。
 *
 * 网页版中用 audioPlayer.ontimeupdate 驱动进度条与歌词高亮，
 * Android 侧改为 200ms 轮询写入 StateFlow，由 Compose 订阅驱动 UI。
 */
object MusicPlayer {

    private const val TICK_INTERVAL_MS = 200L

    private val scope = CoroutineScope(Dispatchers.Main.immediate + SupervisorJob())

    private var _player: ExoPlayer? = null
    val player: ExoPlayer? get() = _player

    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    /** 播放结束回调（网页版 audioPlayer.onended），由 ViewModel 接管自动下一首 */
    var onSongFinished: (() -> Unit)? = null

    private var tickJob: Job? = null

    fun init(context: Context) {
        if (_player != null) return
        val exoPlayer = ExoPlayer.Builder(context.applicationContext).build()
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _state.update { it.copy(isPlaying = isPlaying) }
                if (isPlaying) startTick() else stopTick()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) onSongFinished?.invoke()
            }
        })
        _player = exoPlayer
    }

    /**
     * 播放指定歌曲。
     * [url] 为第三方解析接口返回的音频直链。
     */
    fun play(song: Song, url: String) {
        val exoPlayer = _player ?: return
        _state.update { it.copy(song = song, positionMs = 0L, durationMs = 0L) }

        val item = MediaItem.Builder()
            .setUri(url)
            .setMediaId(song.id)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(song.title)
                    .setArtist(song.artist)
                    .setAlbumTitle(song.album)
                    .setArtworkUri(song.artwork?.toUri())
                    .build()
            )
            .build()

        exoPlayer.setMediaItem(item)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    fun togglePlayPause() {
        val exoPlayer = _player ?: return
        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
    }

    fun pause() {
        _player?.pause()
    }

    fun seekTo(positionMs: Long) {
        _player?.seekTo(positionMs.coerceAtLeast(0L))
    }

    /** 高清封面回填后同步更新 UI 状态 */
    fun updateArtwork(song: Song, artwork: String) {
        _state.update { current ->
            if (current.song?.id == song.id) current.copy(song = song.copy(artwork = artwork)) else current
        }
    }

    private fun startTick() {
        if (tickJob?.isActive == true) return
        tickJob = scope.launchTick()
    }

    private fun stopTick() {
        tickJob?.cancel()
        tickJob = null
    }

    private fun CoroutineScope.launchTick(): Job = kotlinx.coroutines.launch {
        while (true) {
            val exoPlayer = _player ?: break
            _state.update {
                it.copy(
                    positionMs = exoPlayer.currentPosition.coerceAtLeast(0L),
                    durationMs = exoPlayer.duration.coerceAtLeast(0L)
                )
            }
            delay(TICK_INTERVAL_MS)
        }
    }

    fun release() {
        stopTick()
        _player?.release()
        _player = null
    }
}
