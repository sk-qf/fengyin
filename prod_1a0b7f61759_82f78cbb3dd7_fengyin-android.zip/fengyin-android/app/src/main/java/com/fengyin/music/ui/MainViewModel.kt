package com.fengyin.music.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.fengyin.music.data.model.LyricLine
import com.fengyin.music.data.model.Quality
import com.fengyin.music.data.model.Song
import com.fengyin.music.data.remote.NetworkModule
import com.fengyin.music.data.repository.MusicRepository
import com.fengyin.music.player.MusicPlayer
import com.fengyin.music.player.PlayerState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HomeUiState(
    val keyword: String = "",
    val songs: List<Song> = emptyList(),
    val page: Int = 1,
    val isEnd: Boolean = false,
    val isLoading: Boolean = false,
    val searched: Boolean = false,
    val error: String? = null
)

/**
 * 全局唯一 ViewModel：
 *   - 搜索 / 分页（对应源码 searchMusic + loadSearchList）
 *   - 播放调度（对应 playSong / prevBtn / nextBtn / onended）
 *   - 歌词加载与状态暴露（对应 fetchLyrics + timeupdate 高亮）
 */
class MainViewModel(private val repository: MusicRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    private val _lyrics = MutableStateFlow<List<LyricLine>>(emptyList())
    val lyrics: StateFlow<List<LyricLine>> = _lyrics.asStateFlow()

    private val _quality = MutableStateFlow(Quality.HIGH)
    val quality: StateFlow<Quality> = _quality.asStateFlow()

    val playerState: StateFlow<PlayerState> = MusicPlayer.state

    private var currentIndex = -1

    private val playlist: List<Song>
        get() = _uiState.value.songs

    init {
        MusicPlayer.onSongFinished = { playNext() }
    }

    // ---------------- 搜索 ----------------

    fun onKeywordChange(value: String) {
        _uiState.update { it.copy(keyword = value) }
    }

    fun search() {
        if (_uiState.value.keyword.isBlank()) return
        loadPage(1)
    }

    fun prevPage() {
        val state = _uiState.value
        if (state.page > 1) loadPage(state.page - 1)
    }

    fun nextPage() {
        val state = _uiState.value
        if (!state.isEnd) loadPage(state.page + 1)
    }

    private fun loadPage(page: Int) {
        val keyword = _uiState.value.keyword.trim()
        if (keyword.isEmpty()) return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            runCatching { repository.search(keyword, page) }
                .onSuccess { result ->
                    _uiState.update {
                        it.copy(
                            songs = result.songs,
                            page = page,
                            isEnd = result.isEnd || result.songs.isEmpty(),
                            isLoading = false,
                            searched = true,
                            error = null
                        )
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(isLoading = false, searched = true, error = error.message ?: "加载失败")
                    }
                }
        }
    }

    // ---------------- 播放 ----------------

    fun playSong(index: Int) {
        val songs = playlist
        if (index !in songs.indices) return

        currentIndex = index
        val song = songs[index]
        MusicPlayer.play(song, repository.playUrl(song.id, _quality.value))
        loadLyrics(song)
    }

    fun togglePlayPause() = MusicPlayer.togglePlayPause()

    fun playNext() {
        val songs = playlist
        if (songs.isEmpty()) return
        playSong(if (currentIndex >= songs.lastIndex) 0 else currentIndex + 1)
    }

    fun playPrev() {
        val songs = playlist
        if (songs.isEmpty()) return
        playSong(if (currentIndex <= 0) songs.lastIndex else currentIndex - 1)
    }

    fun seekTo(positionMs: Long) = MusicPlayer.seekTo(positionMs)

    fun setQuality(quality: Quality) {
        if (quality == _quality.value) return
        _quality.value = quality

        val index = currentIndex
        if (index in playlist.indices) {
            val resumePosition = MusicPlayer.state.value.positionMs
            playSong(index)
            MusicPlayer.seekTo(resumePosition)
        }
    }

    fun isCurrent(song: Song): Boolean = MusicPlayer.state.value.song?.id == song.id

    private fun loadLyrics(song: Song) {
        viewModelScope.launch {
            _lyrics.value = emptyList()

            runCatching { repository.lyrics(song.id) }
                .onSuccess { _lyrics.value = it }

            runCatching { repository.highResArtwork(song.id) }
                .onSuccess { url -> if (!url.isNullOrEmpty()) MusicPlayer.updateArtwork(song, url) }
        }
    }

    companion object {
        val Factory = viewModelFactory {
            initializer { MainViewModel(NetworkModule.repository) }
        }
    }
}
