package com.fengyin.music.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// 与网页版源码 tailwind 配置保持一致：brand + anime 两套色板
private val Brand400 = Color(0xFF38BDF8)
private val Brand500 = Color(0xFF0EA5E9)
private val Brand600 = Color(0xFF0284C7)
private val Brand700 = Color(0xFF0369A1)
private val Brand900 = Color(0xFF0C4A6E)
private val AnimePale = Color(0xFFE6F4FF)
private val AnimeSky = Color(0xFF90CAF9)
private val AnimeWhite = Color(0xFFF8FBFF)

private val DarkColors = darkColorScheme(
    primary = Brand400,
    onPrimary = Color(0xFF04263A),
    primaryContainer = Brand600,
    onPrimaryContainer = AnimeWhite,
    secondary = AnimeSky,
    onSecondary = Color(0xFF04263A),
    background = Color(0xFF0F172A),      // html.dark background-color
    onBackground = Color(0xFFE0F2FE),
    surface = Color(0xFF101E31),
    onSurface = Color(0xFFE0F2FE),
    surfaceVariant = Color(0xFF14304C),
    onSurfaceVariant = Color(0xFF7DD3FC),
    outline = Color(0x3D0EA5E9)
)

private val LightColors = lightColorScheme(
    primary = Brand600,
    onPrimary = Color.White,
    primaryContainer = AnimePale,
    onPrimaryContainer = Brand900,
    secondary = Brand500,
    onSecondary = Color.White,
    background = AnimeWhite,             // html.light background-color
    onBackground = Brand900,
    surface = Color.White,
    onSurface = Brand900,
    surfaceVariant = AnimePale,
    onSurfaceVariant = Color(0xFF075985),
    outline = Color(0xFFBAE6FD)
)

@Composable
fun FengYinTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
